<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Pendaftaran</title>
  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords"
    content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">

  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Raleway|Candal">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
  <!--banner-->
  <section>	
      <nav>
        <div class="navbar-header navbar-fixed-top" style="height: 60px;">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          </button>
          <a class="navbar-brand" class="img-responsive"
              style="width: 140px; margin-top: 0px; margin-left: 170px;"></a>
        </div>
        <br><br><br><br>
      </nav>
      <nav class="navbar navbar-default navbar-fixed-top" style="margin-top: 50px;">
        <div class="container">
          <div class="col-md-12">
            <div class="navbar-header" id="myNavbar">
              <ul class="nav navbar-nav" style="margin-left: 65px;">
                <li class="active"><a href="index.php">HOME</a></li>
                <li class=""><a href="index.php">ABOUT</a></li>
                <li class=""><a href="index.php">PHD & DOCTOR</a></li>
                <li class=""><a href="index.php">CONTACT</a></li>
                <li class=""><a href="Pendaftaran.php">PENDAFTARAN</a></li>
				        <li class=""><a href="logout.php">LOGOUT</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
  </section>
  <!--/ banner-->
  <!--service-->
  <section id="" class="section-padding2">
    <div class="container">
      <br><br><br>
      <br><br><br>
      <div class="col-md-12">
        <center>
          <h2 class="ser-title" style="color: black;">Layanan</h2>
          <hr class="botm-line">
        </center>
        <br><br><br>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Pendaftaran</h2>
          <hr class="botm-line">
          <p>Terdapat Form untuk mendaftarkan diri menjadi pasien Rumah Sakit Mardi Wakuyo</p>
			<a href="daftar/daftarperiksa.php" class="btn btn-appoint">Daftar Sekarang</a>
        </div>
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Resep Pemeriksaan</h2>
          <hr class="botm-line">
          <p>Terdapat list daftar Resep Pemeriksaan pasien yang telah terdaftar sebelumnya.</p>
			<a href="resep/resep.php" class="btn btn-appoint">Masuk Ke Resep</a>

        </div>
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Riwayat Pemeriksaan</h2>
          <hr class="botm-line">
          <p>Terdapat list daftar Riwayat Pemeriksaan pasien yang telah terdaftar sebelumnya.</p>
			<a href="riwayat/riwayat.php" class="btn btn-appoint">Masuk ke Riwayat</a>

        </div>
      </div>
    </div>
  </section>
  <!--/ service-->
 <br><br><br>
 
 <footer id="footer">
    <div class="top-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Slogan</h4>
            </div>
            <div class="info-sec">
              <p>“Kesehatan Anda adalah Prioritas Kami”
              </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Quick Links</h4>
            </div>
            <div class="info-sec">
              <ul class="quick-info">
                <li><a href="index.php"><i class="fa fa-circle"></i>Home</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Follow us</h4>
            </div>
            <div class="info-sec">
              <ul class="social-icon">
                <li class="bglight-blue"><i class="fa fa-facebook"></i></li>
                <li class="bgred"><i class="fa fa-google-plus"></i></li>
                <li class="bgdark-blue"><i class="fa fa-linkedin"></i></li>
                <li class="bglight-blue"><i class="fa fa-twitter"></i></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-line">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            © Copyright Merdi Waluyo. All Rights Reserved
            <div class="credits">
              Developed by Kelompok 3
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--/ footer-->

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="contactform/contactform.js"></script>

</body>

</html>
