<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mardi Waluyo Hospital</title>
  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords"
    content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">

  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Raleway|Candal">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  
  <script src="vue/vue.js"></script>
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:login/index.php?pesan=belum_login");
	}
	?>
	
  <!--banner-->
  <section id="banner" class="banner">
    <div class="bg-color">
      <nav>
        <div class="navbar-header navbar-fixed-top" style="height: 60px;">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          </button>
          <a class="navbar-brand" href="#"><img src="img/logo2.png" class="img-responsive"
              style="width: 140px; margin-top: 0px; margin-left: 170px;"></a>
        </div>
        <br><br><br><br>
      </nav>
      <nav class="navbar navbar-default navbar-fixed-top" style="margin-top: 50px;">
        <div class="container">
          <div class="col-md-12">
            <div class="navbar-header" id="myNavbar">
              <ul class="nav navbar-nav" style="margin-left: 65px;">
                <li class="active"><a href="#banner">HOME</a></li>
                <li class=""><a href="#about">ABOUT</a></li>
                <li class=""><a href="#doctor-team">PHD & DOCTOR</a></li>
                <li class=""><a href="#contact">CONTACT</a></li>
                <li class=""><a href="Pendaftaran.php">PENDAFTARAN</a></li>
				        <li class=""><a href="logout.php">LOGOUT</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
      <div class="container">
        <div class="row">
          <div class="banner-info">
            <div class="banner-logo text-center">
              <img src="img/logo3.png" class="img-responsive">
            </div>
            <div class="banner-text text-center">
			<h2>Selamat datang, <?php echo $_SESSION['username']; ?>!</h2>
              <h1 class="white">MELAYANI DENGAN SEPENUH HATI!!</h1>
              <p>Jl. Kalimantan 113, Kota Blitar<br> Blitar, Jawa Timur, Indonesia 66131</p>
              <a href="Pendaftaran.php" class="btn btn-appoint">Make an Appointment.</a>
            </div>
            <div class="overlay-detail text-center">
              <a href="#about"><i class="fa fa-angle-down"></i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ banner-->
  <!--service-->
  <section id="about" class="section-padding">
    <div class="container">
      <br><br><br>
      <br><br><br>
      <div class="col-md-12">
        <center>
          <h2 class="ser-title" style="color: black;">About Us!</h2>
          <hr class="botm-line">
        </center>
        <br><br><br>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Story</h2>
          <hr class="botm-line">
          <p>&nbsp&nbsp&nbsp&nbsp Berlatar belakang sejarah para pendirinya yang kuat akan nilai-nilai pengabdian dan kejuangan, Rumah Sakit Mardi Waluyo merupakan sebuah rumah sakit yang telah memiliki pengalaman selama lebih dari 60 tahun di dalam dunia pelayanan kesehatan.<br><br>
          &nbsp&nbsp&nbsp&nbsp Kebutuhan pasien akan kesehatan menjadi fokus utama bagi Rumah Sakit Mardi Waluyo. Oleh karena itu, Rumah Sakit Mardi Waluyo menjaga kualitas pelayanannya dengan mempekerjakan dokter-dokter serta staf medis yang berpengalaman dalam bidangnya dan menyediakan layanan-layanan yang dibutuhkan oleh pasien.</p>
        </div>
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Visi</h2>
          <hr class="botm-line">
          <p>Menjadi rumah sakit nasional dengan pelayanan prima, cepat dan dapat dihandalkan.</p>
        </div>
        <div class="col-md-4 col-sm-4">
          <h2 class="ser-title">Misi</h2>
          <hr class="botm-line">
          <p>1. Menyelenggarakan pelayanan bermutu &nbsp&nbsp&nbsp&nbspdengan mengutamakan keselamatan pasien<br>
            2. Meningkatkan mutu SDM yang berfokus pada &nbsp&nbsp&nbsp&nbspkepuasan pelanggan dan menjunjung tinggi &nbsp&nbsp&nbsp&nbspetika profesi<br>
            3. Mengembangkan produk unggulan<br>
            4. Mengelola organisasi secara efektif dan &nbsp&nbsp&nbsp&nbspefisien</p>
        </div>
      </div>
    </div>
  </section>
  <!--/ service-->
  <!--doctor team-->
  <section id="doctor-team" class="section-padding" style="background-color: rgb(250, 178, 155);">
    <div class="container">
      <div class="row">
        <center>
          <h2 class="ser-title" style="color: white;">Meet Our Doctors!</h2>
          <hr class="botm-line">
        </center>
        <br><br><br>
        <div class="col-md-3 col-sm-3 col-xs-6">
          <div class="thumbnail">
            <img src="img/doctor1.jpg" alt="..." class="team-img">
            <div id="app" class="caption">
              <br>
              <button class="btn badge" @click="btnClick" @mouseover="hover = true" @mouseout="hover = false" >Octavia Eka</button>
              <br>
              <p v-if="hover">Dokter Gigi</p>
              <br>
              <ul class="list-inline">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.instagram.com/octaviaekarf/?hl=id"><i class="fa fa-instagram"></i></a></li>
                <li><a href="mailto:octaviaeka43@gmail.com"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-6">
          <div class="thumbnail">
            <img src="img/doctor2.jpg" alt="..." class="team-img">
            <div id="app2" class="caption">
              <br>
              <button class="btn badge" @click="btnClick" @mouseover="hover = true" @mouseout="hover = false" >Denny Prastyo</button>
              <br>
              <p v-if="hover">Dokter Bedah</p>
              <br>
              <ul class="list-inline">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.instagram.com/denny_prastyo_inkiriwang/?hl=id"><i class="fa fa-instagram"></i></a></li>
                <li><a href="mailto:dennyprastyo9f@gmail.com"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-6">
          <div class="thumbnail">
            <img src="img/doctor4.jpg" alt="..." class="team-img">
            <div id="app3" class="caption">
              <br>
              <button class="btn badge" @click="btnClick" @mouseover="hover = true" @mouseout="hover = false" >Mohammad Egi</button>
              <br>
              <p v-if="hover">Dokter Mata</p>
              <br>
              <ul class="list-inline">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.instagram.com/megek_/?hl=id"><i class="fa fa-instagram"></i></a></li>
                <li><a href="mailto:mohammadegisn@gmail.com"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-6">
          <div class="thumbnail">
            <img src="img/doctor3.jpg" alt="..." class="team-img">
            <div id="app4" class="caption">
              <br>
              <button class="btn badge" @click="btnClick" @mouseover="hover = true" @mouseout="hover = false" >Endang Supraptih</button>
              <br>
              <p v-if="hover">Dokter Kandungan</p>
              <br>
              <ul class="list-inline">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ doctor team-->
  <!--contact-->
  <section id="contact" class="section-padding">
    <div class="container">
      <div class="row">
        <center>
          <h2 class="ser-title">Contact us</h2>
          <hr class="botm-line">
        </center>
        <br><br><br>
        <div class="col-md-4 col-sm-4">
          <h3>Contact Info</h3>
          <div class="space"></div>
          <p><i class="fa fa-map-marker fa-fw pull-left fa-2x"></i>Jl. Kalimantan 113, Kota Blitar<br> Blitar, Jawa Timur, Indonesia 66131</p>
          <div class="space"></div>
          <p><i class="fa fa-envelope-o fa-fw pull-left fa-2x"></i>rsudmardiwaluyo@yahoo.com</p>
          <div class="space"></div>
          <p><i class="fa fa-phone fa-fw pull-left fa-2x"></i>(0342) 802118</p>
        </div>
        <div class="col-md-8 col-sm-8 marb20">
          <div class="contact-info">
            <h3 class="cnt-ttl">Untuk Pertanyaan, Saran dan Kritik Silahkan Isi Dalam Form Berikut!</h3>
            <div class="space"></div>
            <div id="sendmessage">Your message has been sent. Thank you!</div>
            <div id="errormessage"></div>
            <form action="" method="post" role="form" class="contactForm">
              <div class="form-group">
                <input type="text" name="name" class="form-control br-radius-zero" id="name" placeholder="Your Name"
                  data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="email" class="form-control br-radius-zero" name="email" id="email" placeholder="Your Email"
                  data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control br-radius-zero" name="subject" id="subject" placeholder="Subject"
                  data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control br-radius-zero" name="message" rows="5" data-rule="required"
                  data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validation"></div>
              </div>
              <div class="form-action">
                <button type="submit" class="btn btn-form">Send Message</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ contact-->
  <script>
    var app = new Vue({
      el: "#app",
      data: {
        hover: false
      },
      methods: {
          btnClick: function(){
              alert(`Octavia Eka. Specialis Dokter Gigi`);
          }
      }
    })
    var app2 = new Vue({
      el: "#app2",
      data: {
        hover: false
      },
      methods: {
          btnClick: function(){
              alert(`Denny Prastyo. Specialis Dokter Bedah`);
          }
      }
    })
    var app3 = new Vue({
      el: "#app3",
      data: {
        hover: false
      },
      methods: {
          btnClick: function(){
              alert(`Mohammad Egi. Specialis Dokter Mata`);
          }
      }
    })
    var app4 = new Vue({
      el: "#app4",
      data: {
        hover: false
      },
      methods: {
          btnClick: function(){
              alert(`Endang Supraptih. Specialis Dokter Kandungan`);
          }
      }
    })
  </script>
  <!--footer-->
  <footer id="footer">
    <div class="top-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Slogan</h4>
            </div>
            <div class="info-sec">
              <p>“Kesehatan Anda adalah Prioritas Kami”
              </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Quick Links</h4>
            </div>
            <div class="info-sec">
              <ul class="quick-info">
                <li><a href="index.php"><i class="fa fa-circle"></i>Home</a></li>
                <li><a href="#about"><i class="fa fa-circle"></i>About</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Follow us</h4>
            </div>
            <div class="info-sec">
              <ul class="social-icon">
                <li class="bglight-blue"><i class="fa fa-facebook"></i></li>
                <li class="bgred"><i class="fa fa-google-plus"></i></li>
                <li class="bgdark-blue"><i class="fa fa-linkedin"></i></li>
                <li class="bglight-blue"><i class="fa fa-twitter"></i></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-line">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            © Copyright Merdi Waluyo. All Rights Reserved
            <div class="credits">
              Developed by Kelompok 3
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--/ footer-->

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="contactform/contactform.js"></script>

</body>

</html>