<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Daftar Resep</title>
  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords"
    content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">

  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Raleway|Candal">
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<?php
include "koneksi.php";
?>
  <section>	
      <nav class="navbar navbar-default" style="margin-top: 0px;">
        <div class="container">
          <div class="col-md-12">
            <div class="navbar-header" id="myNavbar">
              <ul class="nav navbar-nav" style="margin-left: 65px;">
                <li class="active"><a href="../index.php">HOME</a></li>
                <li class=""><a href="../index.php">ABOUT</a></li>
                <li class=""><a href="../index.php">PHD & DOCTOR</a></li>
                <li class=""><a href="../index.php">CONTACT</a></li>
                <li class=""><a href="../Pendaftaran.php">PENDAFTARAN</a></li>
				        <li class=""><a href="../logout.php">LOGOUT</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
  </section>

	<nav>
    <br>
    <a class="btn btn-warning" style="margin-left :20px;" href="../Pendaftaran.php">Kembali ke Pendaftaran</a>
  </nav>
	
  <div class="container">
		<div class="col-md-12">
      <br>
      <center>
        <h1> Resep Pasien</h1>
      </center>
      <br><br>
    </div>
    <div class="main">
      <div class="content">
        <table class="table1" width="100%" cellpadding="0" cellspacing="0">
          <thead>
            <tr>
              <th width="10%">No</th>
              <th width="10%">Nama Dokter</th>
              <th width="10%">Nama Pasien</th>
              <th width="10%">Obat</th>
              <th width="10%">Harga</th>
              <th width="10%">Status Transaksi</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php 
              include 'koneksi.php';
              $no = 1;
              $data = mysqli_query($kon,"select Dokter,nama,obat,harga,status_transaksi from resep");
              while($d = mysqli_fetch_array($data)){
                ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $d['Dokter']; ?></td>
                  <td><?php echo $d['nama']; ?></td>
                  <td><?php echo $d['obat']; ?></td>
                  <td><?php echo $d['harga']; ?></td>
                  <td><?php echo $d['status_transaksi']; ?></td>
                </tr>
                <?php 
              }
              ?>
            </tr>              
          </tbody>
        </table>
      </div>
    </div>          
  </div>
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>

  <footer id="footer">
    <div class="top-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Slogan</h4>
            </div>
            <div class="info-sec">
              <p>“Melayani Dengan Hati”
              </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Quick Links</h4>
            </div>
            <div class="info-sec">
              <ul class="quick-info">
                <li><a href="index.php"><i class="fa fa-circle"></i>Home</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 marb20">
            <div class="ftr-tle">
              <h4 class="white no-padding">Follow us</h4>
            </div>
            <div class="info-sec">
              <ul class="social-icon">
                <li class="bglight-blue"><i class="fa fa-facebook"></i></li>
                <li class="bgred"><i class="fa fa-google-plus"></i></li>
                <li class="bgdark-blue"><i class="fa fa-linkedin"></i></li>
                <li class="bglight-blue"><i class="fa fa-twitter"></i></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-line">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            © Copyright Merdi Waluyo. All Rights Reserved
            <div class="credits">
              Developed by Kelompok 3
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--/ footer-->

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="contactform/contactform.js"></script>

</body>

</html>
